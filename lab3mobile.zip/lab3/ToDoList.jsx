import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

function ToDoList({ tasks }) {
  return (
    <View>
      {tasks.map((task, index) => (
        <View key={index} style={styles.task}>
          <Text>{task}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  task: {
    padding: 10,
    borderColor: '#ccc',
  }
});

export default ToDoList;
